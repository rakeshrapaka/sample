package com.amsolutions.reliablesampleapplication.model

data class Country (

    val capital: String = "",
    val code: String = "",
    val currency: Currency,
    val flag:String,
    val name:String,
    val region:String,
    val language: Language

)