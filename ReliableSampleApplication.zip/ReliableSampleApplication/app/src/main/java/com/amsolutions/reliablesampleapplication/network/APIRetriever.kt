package com.amsolutions.reliablesampleapplication.network

import com.amsolutions.reliablesampleapplication.model.CountriesResponse
import com.amsolutions.reliablesampleapplication.model.Country


import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class APIRetriever {
    private val remoteInterface:RemoteInterface

    companion object{
        var BASEURL = "https://gist.githubusercontent.com/peymano-wmt/32dcb892b06648910ddd40406e37fdab/raw/db25946fd77c5873b0303b858e861ce724e0dcd0/"
    }

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASEURL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        remoteInterface = retrofit.create(RemoteInterface::class.java)
    }

    suspend fun getCountries():List<Country>{
        return remoteInterface.getCountries()
    }
}