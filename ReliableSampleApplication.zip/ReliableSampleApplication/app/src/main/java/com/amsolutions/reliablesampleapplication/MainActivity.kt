package com.amsolutions.reliablesampleapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.amsolutions.reliablesampleapplication.databinding.ActivityMainBinding
import com.amsolutions.reliablesampleapplication.model.CountriesResponse
import com.amsolutions.reliablesampleapplication.model.Country
import com.amsolutions.reliablesampleapplication.network.APIRetriever
import com.amsolutions.reliablesampleapplication.ui.CountriesAdapter
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.coroutineContext


class MainActivity : AppCompatActivity() {

    private val countriesRetriever : APIRetriever = APIRetriever()
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_main)
//        binding
        //this.countriesRecycleView = findViewById<RecyclerView>(R.id.countriesRecycleView)
        initRecyclerView()
        fetchCountries()
    }

    private fun fetchCountries() {
        val fetchCountriesJob = Job()

        val errorHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
            Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show()
        }

        val scope = CoroutineScope(fetchCountriesJob + Dispatchers.Main)

        scope.launch (errorHandler){
            // fetching countries list (data)
            val countries = countriesRetriever.getCountries()

            // Rendering data in recyclerview
            renderData(countries)

        }
    }

    private fun renderData(countries: List<Country>) {
        binding.countriesRecycleView.adapter = CountriesAdapter(countries)
    }

    private fun initRecyclerView() {

        binding.countriesRecycleView.layoutManager = LinearLayoutManager(this)
    }
}