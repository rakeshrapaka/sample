package com.amsolutions.reliablesampleapplication.model

data class CountriesResponse(
    val countries : List<Country> = mutableListOf()
)
