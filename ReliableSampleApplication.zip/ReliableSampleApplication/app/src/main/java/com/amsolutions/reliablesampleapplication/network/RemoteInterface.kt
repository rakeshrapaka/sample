package com.amsolutions.reliablesampleapplication.network

import com.amsolutions.reliablesampleapplication.model.CountriesResponse
import com.amsolutions.reliablesampleapplication.model.Country

import retrofit2.http.GET

interface RemoteInterface {
    @GET("countries.json")
    suspend fun getCountries(): List<Country>
}