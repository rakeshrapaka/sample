package com.amsolutions.reliablesampleapplication.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amsolutions.reliablesampleapplication.R
import com.amsolutions.reliablesampleapplication.model.CountriesResponse
import com.amsolutions.reliablesampleapplication.model.Country

class CountriesAdapter(private val countriesResponse: List<Country>):RecyclerView.Adapter<CountriesAdapter.ViewHolder>() {

    inner class ViewHolder(view: View): RecyclerView.ViewHolder(view){

        val name: TextView
        val code: TextView
        val capital: TextView

        init {
            name = view.findViewById(R.id.name)
            code = view.findViewById(R.id.code)
            capital = view.findViewById(R.id.capital)
        }

        fun bind(country: Country){
            name.text = country.name+", "+country.region
            code.text = country.code
            capital.text = country.capital
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(view = LayoutInflater.from(parent.context).inflate(R.layout.country_item,parent,false))
    }

    override fun getItemCount(): Int {
        return countriesResponse.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(country = countriesResponse.get(position))
    }
}